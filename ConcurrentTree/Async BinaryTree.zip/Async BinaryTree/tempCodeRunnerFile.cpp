    // TreeNode *new_node = new TreeNode();
    // thread thread1(
    //     {new_node = obj.iterativeSearch(arr[searchidx]);
    //         if (new_node != NULL) {
    //             obj.deleteNode(obj.root, arr[searchidx]);
    //             cout << "Value Deleted" << endl;
    //         }
    //         else {
    //             cout << "Value NOT found" << endl;
    //         } });

    //         TreeNode *new_node = new TreeNode();
